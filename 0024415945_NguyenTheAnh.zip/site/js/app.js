// Câu 2: viết JavaScript tại đây

const API_URL = "http://localhost:4000";

const formatDateTime = (iso) => {
    return new Date(iso).toLocaleString("vi-VN", {
        timeZone: "Asia/Ho_Chi_Minh",
        hour: "2-digit",
        minute: "2-digit",
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
    });
};

const formatSeats = (event) => {
    const conLai = event.capacity - event.registeredCount;

    if (conLai <= 0) {
        return "Hết chỗ";
    }

    return `Còn ${conLai}/${event.capacity} chỗ`;
};

const renderEvents = (events) => {
    const eventList = document.querySelector("#event-list");

    const cards = [];

    events.forEach((event) => {
        const article = document.createElement("article");
        article.className = "card";

        const img = document.createElement("img");
        img.setAttribute("src", "img/event.svg");
        img.setAttribute("alt", "Hình ảnh sự kiện");

        const h2 = document.createElement("h2");

        const link = document.createElement("a");
        link.setAttribute(
            "href",
            `event-detail.html?id=${event.id}`
        );
        link.textContent = event.name;

        h2.appendChild(link);

        const time = document.createElement("time");
        time.setAttribute("datetime", event.startTime);
        time.textContent = formatDateTime(event.startTime);

        const pTime = document.createElement("p");
        pTime.appendChild(time);

        const pLocation = document.createElement("p");
        pLocation.textContent = event.location;

        const pSeats = document.createElement("p");
        pSeats.textContent = formatSeats(event);

        if (event.registeredCount >= event.capacity) {
            pSeats.className = "full";
        }

        article.appendChild(img);
        article.appendChild(h2);
        article.appendChild(pTime);
        article.appendChild(pLocation);
        article.appendChild(pSeats);

        cards.push(article);
    });

    eventList.replaceChildren(...cards);
};

const loadEvents = async (keyword) => {
    const status = document.querySelector("#status");

    status.textContent = "Đang tải…";

    try {
        const params = new URLSearchParams();
        params.set("pageSize", "50");

        if (keyword.trim() !== "") {
            params.set("q", keyword.trim());
        }

        const response = await fetch(
            `${API_URL}/api/events?${params.toString()}`
        );

        if (!response.ok) {
            throw new Error("Không tải được dữ liệu");
        }

        const data = await response.json();

        renderEvents(data.items);

        if (data.items.length === 0) {
            status.textContent =
                "Không có sự kiện nào khớp từ khoá.";
        } else {
            status.textContent =
                `Tìm thấy ${data.items.length} sự kiện`;
        }

    } catch (error) {
        status.textContent =
            "Không tải được dữ liệu, vui lòng thử lại.";
    }
};

const searchForm = document.querySelector("#search-form");

searchForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const keyword = document.querySelector("#keyword").value.trim();

    loadEvents(keyword);
});

loadEvents("");